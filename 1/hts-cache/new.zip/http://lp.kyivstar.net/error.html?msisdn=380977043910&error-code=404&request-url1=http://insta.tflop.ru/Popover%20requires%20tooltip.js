<!DOCTYPE html>
<html lang="uk">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="Cache-Control" content="max-age=86400, must-revalidate" />
  <link rel="stylesheet" href="../css/styles.css">
  <title>Kyivstar</title>
  <script>function getUrlVars() {var vars = {},parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi,function(m,key,value){vars[key]=value});return vars}</script>
  <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
  new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
  j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
  '//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
  })(window,document,'script','dataLayer','GTM-KR8LSH');</script>
</head>

<body>
  <!-- Google Tag Manager -->
  <noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-KR8LSH" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
  <!-- End Google Tag Manager -->
  <div class="h-block">
    <svg width="185" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" xml:space="preserve" viewBox="0 0 210 52">
      <path class="logo__dots" d="M111.9,11.1c0-2.7-2.2-4.8-4.9-4.8c-2.6,0-4.8,2.1-4.8,4.8c0,2.7,2.2,4.9,4.8,4.9  C109.7,16,111.9,13.9,111.9,11.1"/>
      <path class="logo__dots" d="M124.4,11.1c0-2.7-2.2-4.8-4.9-4.8c-2.7,0-4.8,2.1-4.8,4.8c0,2.7,2.2,4.9,4.8,4.9  C122.2,16,124.4,13.9,124.4,11.1"/>
      <path class="logo__letter" d="M78,27.6l6.2-7.4c0.5-0.5,0.2-1.1-0.5-1.1H79c-0.4,0-0.9,0.2-1.2,0.6l-4.2,5.6V20c0-0.7-0.3-1-1-1h-3.4  c-0.7,0-1,0.3-1,1v17.2c0,0.7,0.3,1,1,1h3.4c0.7,0,1-0.3,1-1v-6.3l5.6,6.6c0.3,0.4,0.7,0.7,1.1,0.7h4.9c0.6,0,0.8-0.6,0.5-1.1  L78,27.6z"/>
      <path class="logo__letter" d="M115,19h-3.6c-0.7,0-1,0.3-1,1v17.2c0,0.7,0.3,1,1,1h3.6c0.7,0,1-0.3,1-1V20C115.9,19.4,115.7,19,115,19"/>
      <path class="logo__letter" d="M202.6,19l-7.9,0c-0.7,0-1,0.3-1,1v17.2c0,0.7,0.3,1,1,1h3.6c0.7,0,1-0.3,1-1v-4.6h3.1c4.3,0,7.6-2.4,7.6-6.6 C210,21.7,206.6,19,202.6,19 M202.2,28.4h-2.9v-4.9h2.8C205.9,23.5,206.2,28.4,202.2,28.4"/>
      <path class="logo__letter" d="M172.5,19h-13.9c-0.7,0-1,0.3-1,1v3.3c0,0.7,0.3,1,1,1h4.2v12.8c0,0.7,0.3,1,1,1h3.6c0.7,0,1-0.3,1-1V24.4h4.2  c0.7,0,1-0.3,1-1V20C173.5,19.3,173.1,19,172.5,19"/>
      <path class="logo__letter" d="M134.3,27.7c3.4-3.3,1.1-8.7-4.1-8.7l-8.8,0c-0.7,0-1,0.3-1,1v17.2c0,0.7,0.3,1,1,1l9.6,0  C137.9,38.2,139.7,30.3,134.3,27.7 M125.6,23.3h3.5c2.2,0,2.3,3,0,3h-3.5V23.3z M130.2,33.9h-4.6v-3.6h4.6 C133,30.3,133.2,33.9,130.2,33.9"/>
      <path class="logo__letter" d="M105.1,19l-4.4,0l-8,11V20c0-0.7-0.3-1-1-1h-3.3c-0.7,0-1,0.3-1,1v17.2c0,0.7,0.3,1,1,1h4.2l8.1-10.8v9.8  c0,0.7,0.3,1,1,1h3.3c0.7,0,1-0.3,1-1V20C106.1,19.3,105.8,19,105.1,19"/>
      <path class="logo__letter" d="M148.6,33.7c-2.9,0-5.2-2.3-5.2-5.1c0-2.8,2.3-5.1,5.1-5.1c1.6,0,3.3,0.7,4.2,1.5c0.4,0.4,0.7,0.6,1.3,0  l2.2-2.1c0.3-0.3,0.4-0.8-0.1-1.2c-2.1-1.9-4.4-3.2-7.5-3.2c-5.6,0-10.2,4.5-10.2,10.2c0,5.6,4.6,10.2,10.2,10.2  c3.1,0,5.5-1.3,7.5-3.2c0.5-0.5,0.4-1,0.1-1.2l-2.2-2.1c-0.6-0.6-0.9-0.4-1.3,0C151.8,33,150.2,33.7,148.6,33.7"/>
      <path class="logo__letter" d="M191.9,37.2l-6.6-17.5c-0.2-0.5-0.5-0.7-1.1-0.7h-4.4c-0.6,0-0.9,0.3-1.1,0.7l-6.6,17.5c-0.2,0.5,0.1,1,0.7,1h4  c0.3,0,0.7-0.3,0.8-0.6l0.9-2.6h0h6.9h0l0.9,2.6c0.1,0.3,0.5,0.6,0.8,0.6h4C191.8,38.2,192.1,37.8,191.9,37.2 M180.1,30.7L182,25h0  l1.9,5.6H180.1z"/>
      <path class="logo__letter" d="M27.2,19.8c-1.9,0-3.5-1.6-3.5-3.5V3.5c0-1.9,1.6-3.5,3.5-3.5c1.9,0,3.5,1.6,3.5,3.5v12.8  C30.7,18.3,29.1,19.8,27.2,19.8"/>
      <path class="logo__letter" d="M19,25.8c-0.6,1.8-2.6,2.8-4.4,2.2L2.4,24c-1.8-0.6-2.8-2.6-2.2-4.4c0.6-1.8,2.6-2.8,4.4-2.2l12.2,4  C18.6,22,19.6,23.9,19,25.8"/>
      <path class="logo__letter" d="M35.4,25.8c0.6,1.8,2.6,2.8,4.4,2.2l12.2-4c1.8-0.6,2.8-2.6,2.2-4.4c-0.6-1.8-2.6-2.8-4.4-2.2l-12.2,4  C35.8,22,34.8,23.9,35.4,25.8"/>
      <path class="logo__letter" d="M10.5,51.4c-1.6-1.1-1.9-3.3-0.8-4.9l7.5-10.4c1.1-1.6,3.3-1.9,4.9-0.8c1.6,1.1,1.9,3.3,0.8,4.9l-7.5,10.4  C14.2,52.2,12.1,52.6,10.5,51.4"/>
      <path class="logo__letter" d="M43.9,51.4c1.6-1.1,1.9-3.3,0.8-4.9l-7.5-10.4c-1.1-1.6-3.3-1.9-4.9-0.8c-1.6,1.1-1.9,3.3-0.8,4.9L39,50.7  C40.2,52.2,42.4,52.6,43.9,51.4"/>
    </svg>
  </div>
  <div class="wrapper">
    <section class="cb">
      <h1>Шановний абоненте!</h1>
      <p>
        Під час виконання вашого запиту за адресою
        <script>
        var error = getUrlVars()['error-code'],
        url = getUrlVars()['request-url1'];
        document.write('<a href="' + url + '">' + url + '</a> виникла помилка <b>' + error + '</b>&nbsp;');
        switch (error) {
          case '477':
          document.location.href = "http://lp.kyivstar.net/lpshape.html";
          break
          case '400':
          case '404':
          case '405':
          case '410':
          case '411':
          case '413':
          case '414':
          case '425':
          case '431':
          case '434':
          case '508':
          document.write('(невірна адреса).<p>Рекомендації:</p><ul><li>Перевірте коректність адреси.</li></ul>');
          break
          case '401':
          case '402':
          case '403':
          case '406':
          case '407':
          case '408':
          case '409':
          case '417':
          case '423':
          case '426':
          case '429':
          case '449':
          case '451':
          case '500':
          case '501':
          case '502':
          case '503':
          case '504':
          case '507':
          case '509':
          case '511':
          case '599':
          document.write('(обмеження доступу).<p>Рекомендації:</p><ul><li>Перевірте можливість доступу в адміністрації сайту.</li><li>Повторіть спробу пізніше.</li></ul>');
          break
          default:
          document.write('(нетипова).<p>Рекомендації:</p><ul><li>Перевірте коректність адреси.</li><li>Спробуйте зайти на сайт з іншого пристрою.</li></ul>');
        }
        </script>
      </section>

      <section class="cb">
        <p>Ми запустили 4G! Детальніше за <a href="https://kyivstar.ua/uk/4g#utm_source=lp.kyivstar">посиланням</a>.</p>
      </section>

      <section class="cb">
        <h2>Нові тарифи для вашого смартфона</h2>
        <p><a href="https://new.kyivstar.ua/ecare/compatiblePlans?utm_source=lp.kyivstar.net&utm_medium=banner&utm_content=tariffplan&utm_campaign=lp_kyivstar" class="btn">Обрати тариф</a></p>
        <p>Або <a href="https://new.kyivstar.ua/ecare/services?utm_source=lp.kyivstar.net&utm_medium=banner&utm_content=internet_package&utm_campaign=lp_kyivstar">замовте</a> інтернет-пакет з оптимальним обсягом мегабайтів, не змінюючи тариф.</p>
      </section>

      <section class="cb">
        <h2>Можливо прийшов час замінити твій смартфон?</h2>
        <p>Даруємо персональну знижку до 1000 грн на покупку смартфона та інших девайсів в інтернет-магазині <a href="https://shop.kyivstar.ua">shop.kyivstar.ua</a>. Акція діє до кінця місяця.</p>
        <p><a href="https://shop.kyivstar.ua/ua/new-customer" class="btn">Обрати смартфон</a></p>
      </section>

      <section class="cb">
        <h2>Інші корисні сервіси для вашого мобільного</h2>
        <ul>
          <li><a href="http://lp.kyivstar.net/money.html">Мобільні гроші</a> &mdash; оплата послуг грошима з мобільного рахунку</li>
          <li><a href="https://kyivstar.ua/gotv7">Go TV</a> &mdash; Мобільне ТБ, яке завжди з тобою</li>
          <li><a href="http://lp.kyivstar.net/tv.html">Домашнє ТБ</a> &mdash; телеканали в цифровій та HD-якості.</li>
          <li><a href="http://lp.kyivstar.net/465.html">D-Jingle</a> &mdash; музика замість гудків.</li>
          <li><a href="https://kyivstar.ua/radio7">Радіо Київстар</a> &mdash; музична платформа з треками для будь-якого настрою.</li>
        </ul>
      </section>

      <p><strong>Київстар бажає вам приємного дня!</strong></p>
    </div>
  </body>
</html>
